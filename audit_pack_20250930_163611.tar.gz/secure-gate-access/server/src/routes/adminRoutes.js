import express from 'express';
import { getMetrics, getAuditLogs } from '../controllers/adminController.js';
import { attachUserFromToken } from '../middleware/authMiddleware.js';
import attachRequestAudit from '../middleware/auditLogger.js';

const router = express.Router();

// Admin metrics endpoint
router.get('/metrics', attachUserFromToken, attachRequestAudit, getMetrics);

// Audit logs endpoint
router.get('/audit-logs', attachUserFromToken, attachRequestAudit, getAuditLogs);

export default router;