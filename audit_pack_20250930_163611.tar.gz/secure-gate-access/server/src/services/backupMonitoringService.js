/**
 * Backup Monitoring Service for Secure Gate Access Control System
 * 
 * Provides comprehensive monitoring and alerting for backup operations
 * Features:
 * - Prometheus metrics integration
 * - Grafana dashboard data
 * - Alertmanager integration
 * - Real-time monitoring
 * - Performance tracking
 */

import loggingService from './loggingService.js';
import backupService from './backupService.js';
import restoreService from './restoreService.js';
import notificationService from './notificationService.js';

class BackupMonitoringService {
  constructor() {
    this.metrics = {
      backupJobs: {
        total: 0,
        successful: 0,
        failed: 0,
        inProgress: 0
      },
      restoreTests: {
        total: 0,
        successful: 0,
        failed: 0,
        inProgress: 0
      },
      storage: {
        totalSize: 0,
        usedSize: 0,
        availableSize: 0,
        backupCount: 0
      },
      performance: {
        averageBackupDuration: 0,
        averageRestoreDuration: 0,
        lastBackupTime: null,
        lastRestoreTime: null
      },
      alerts: {
        active: 0,
        resolved: 0,
        critical: 0,
        warning: 0
      }
    };
    
    this.alertRules = {
      backupFailure: {
        enabled: true,
        threshold: 1,
        severity: 'critical',
        message: 'Backup job failed'
      },
      restoreFailure: {
        enabled: true,
        threshold: 1,
        severity: 'critical',
        message: 'Restore test failed'
      },
      diskUsageHigh: {
        enabled: true,
        threshold: 90,
        severity: 'warning',
        message: 'Disk usage is high'
      },
      backupAgeHigh: {
        enabled: true,
        threshold: 25,
        severity: 'warning',
        message: 'Backup is too old'
      },
      serviceDown: {
        enabled: true,
        threshold: 1,
        severity: 'critical',
        message: 'Backup service is down'
      }
    };
    
    this.initializeService();
  }

  /**
   * Initialize monitoring service
   */
  async initializeService() {
    try {
      loggingService.logInfo('Backup monitoring service initialized', {
        alertRules: Object.keys(this.alertRules)
      });
      
    } catch (error) {
      loggingService.logError('Failed to initialize backup monitoring service', error);
      throw error;
    }
  }

  /**
   * Record backup job metrics
   */
  recordBackupJob(backupResult) {
    try {
      this.metrics.backupJobs.total++;
      
      if (backupResult.success) {
        this.metrics.backupJobs.successful++;
      } else {
        this.metrics.backupJobs.failed++;
      }
      
      // Update performance metrics
      if (backupResult.duration) {
        this.updateAverageBackupDuration(backupResult.duration);
      }
      
      this.metrics.performance.lastBackupTime = new Date();
      
      // Check for alerts
      this.checkBackupAlerts(backupResult);
      
      loggingService.logInfo('Backup job metrics recorded', {
        backupId: backupResult.backupId,
        success: backupResult.success,
        duration: backupResult.duration
      });
      
    } catch (error) {
      loggingService.logError('Failed to record backup job metrics', error);
    }
  }

  /**
   * Record restore test metrics
   */
  recordRestoreTest(restoreResult) {
    try {
      this.metrics.restoreTests.total++;
      
      if (restoreResult.success) {
        this.metrics.restoreTests.successful++;
      } else {
        this.metrics.restoreTests.failed++;
      }
      
      // Update performance metrics
      if (restoreResult.duration) {
        this.updateAverageRestoreDuration(restoreResult.duration);
      }
      
      this.metrics.performance.lastRestoreTime = new Date();
      
      // Check for alerts
      this.checkRestoreAlerts(restoreResult);
      
      loggingService.logInfo('Restore test metrics recorded', {
        testId: restoreResult.testId,
        success: restoreResult.success,
        duration: restoreResult.duration
      });
      
    } catch (error) {
      loggingService.logError('Failed to record restore test metrics', error);
    }
  }

  /**
   * Update storage metrics
   */
  async updateStorageMetrics() {
    try {
      const storageInfo = await this.getStorageInfo();
      
      this.metrics.storage.totalSize = storageInfo.totalSize;
      this.metrics.storage.usedSize = storageInfo.usedSize;
      this.metrics.storage.availableSize = storageInfo.availableSize;
      this.metrics.storage.backupCount = storageInfo.backupCount;
      
      // Check for disk usage alerts
      this.checkDiskUsageAlerts(storageInfo);
      
      loggingService.logInfo('Storage metrics updated', {
        totalSize: storageInfo.totalSize,
        usedSize: storageInfo.usedSize,
        availableSize: storageInfo.availableSize,
        backupCount: storageInfo.backupCount
      });
      
    } catch (error) {
      loggingService.logError('Failed to update storage metrics', error);
    }
  }

  /**
   * Get storage information
   */
  async getStorageInfo() {
    try {
      // This would get actual storage information
      // For now, return mock data
      return {
        totalSize: 100 * 1024 * 1024 * 1024, // 100GB
        usedSize: 75 * 1024 * 1024 * 1024, // 75GB
        availableSize: 25 * 1024 * 1024 * 1024, // 25GB
        backupCount: 10
      };
    } catch (error) {
      loggingService.logError('Failed to get storage info', error);
      return {
        totalSize: 0,
        usedSize: 0,
        availableSize: 0,
        backupCount: 0
      };
    }
  }

  /**
   * Update average backup duration
   */
  updateAverageBackupDuration(duration) {
    const currentAvg = this.metrics.performance.averageBackupDuration;
    const totalBackups = this.metrics.backupJobs.total;
    
    if (totalBackups === 1) {
      this.metrics.performance.averageBackupDuration = duration;
    } else {
      this.metrics.performance.averageBackupDuration = 
        (currentAvg * (totalBackups - 1) + duration) / totalBackups;
    }
  }

  /**
   * Update average restore duration
   */
  updateAverageRestoreDuration(duration) {
    const currentAvg = this.metrics.performance.averageRestoreDuration;
    const totalRestores = this.metrics.restoreTests.total;
    
    if (totalRestores === 1) {
      this.metrics.performance.averageRestoreDuration = duration;
    } else {
      this.metrics.performance.averageRestoreDuration = 
        (currentAvg * (totalRestores - 1) + duration) / totalRestores;
    }
  }

  /**
   * Check backup alerts
   */
  checkBackupAlerts(backupResult) {
    try {
      // Check backup failure alert
      if (!backupResult.success && this.alertRules.backupFailure.enabled) {
        this.triggerAlert('backupFailure', {
          backupId: backupResult.backupId,
          errors: backupResult.errors,
          severity: this.alertRules.backupFailure.severity
        });
      }
      
    } catch (error) {
      loggingService.logError('Failed to check backup alerts', error);
    }
  }

  /**
   * Check restore alerts
   */
  checkRestoreAlerts(restoreResult) {
    try {
      // Check restore failure alert
      if (!restoreResult.success && this.alertRules.restoreFailure.enabled) {
        this.triggerAlert('restoreFailure', {
          testId: restoreResult.testId,
          backupId: restoreResult.backupId,
          errors: restoreResult.errors,
          severity: this.alertRules.restoreFailure.severity
        });
      }
      
    } catch (error) {
      loggingService.logError('Failed to check restore alerts', error);
    }
  }

  /**
   * Check disk usage alerts
   */
  checkDiskUsageAlerts(storageInfo) {
    try {
      const usagePercentage = (storageInfo.usedSize / storageInfo.totalSize) * 100;
      
      if (usagePercentage > this.alertRules.diskUsageHigh.threshold && 
          this.alertRules.diskUsageHigh.enabled) {
        this.triggerAlert('diskUsageHigh', {
          usagePercentage,
          threshold: this.alertRules.diskUsageHigh.threshold,
          severity: this.alertRules.diskUsageHigh.severity
        });
      }
      
    } catch (error) {
      loggingService.logError('Failed to check disk usage alerts', error);
    }
  }

  /**
   * Check backup age alerts
   */
  async checkBackupAgeAlerts() {
    try {
      const backupHistory = backupService.getBackupHistory(1);
      
      if (backupHistory.length > 0) {
        const lastBackup = backupHistory[0];
        const now = new Date();
        const backupTime = new Date(lastBackup.startTime);
        const ageHours = (now - backupTime) / (1000 * 60 * 60);
        
        if (ageHours > this.alertRules.backupAgeHigh.threshold && 
            this.alertRules.backupAgeHigh.enabled) {
          this.triggerAlert('backupAgeHigh', {
            backupId: lastBackup.backupId,
            ageHours,
            threshold: this.alertRules.backupAgeHigh.threshold,
            severity: this.alertRules.backupAgeHigh.severity
          });
        }
      }
      
    } catch (error) {
      loggingService.logError('Failed to check backup age alerts', error);
    }
  }

  /**
   * Check service status alerts
   */
  async checkServiceStatusAlerts() {
    try {
      const backupStatus = backupService.getStatus();
      const restoreStatus = restoreService.getStatus();
      
      if (!backupStatus.initialized || !restoreStatus.initialized) {
        this.triggerAlert('serviceDown', {
          backupStatus: backupStatus.initialized,
          restoreStatus: restoreStatus.initialized,
          severity: this.alertRules.serviceDown.severity
        });
      }
      
    } catch (error) {
      loggingService.logError('Failed to check service status alerts', error);
    }
  }

  /**
   * Trigger alert
   */
  async triggerAlert(alertType, alertData) {
    try {
      const alert = {
        id: this.generateAlertId(),
        type: alertType,
        severity: alertData.severity,
        message: this.alertRules[alertType].message,
        data: alertData,
        timestamp: new Date(),
        status: 'active'
      };
      
      // Update alert metrics
      this.metrics.alerts.active++;
      if (alertData.severity === 'critical') {
        this.metrics.alerts.critical++;
      } else if (alertData.severity === 'warning') {
        this.metrics.alerts.warning++;
      }
      
      // Send notification
      await this.sendAlertNotification(alert);
      
      loggingService.logInfo('Alert triggered', {
        alertId: alert.id,
        type: alertType,
        severity: alertData.severity
      });
      
    } catch (error) {
      loggingService.logError('Failed to trigger alert', error, {
        alertType,
        alertData
      });
    }
  }

  /**
   * Resolve alert
   */
  async resolveAlert(alertId) {
    try {
      this.metrics.alerts.active--;
      this.metrics.alerts.resolved++;
      
      loggingService.logInfo('Alert resolved', { alertId });
      
    } catch (error) {
      loggingService.logError('Failed to resolve alert', error, { alertId });
    }
  }

  /**
   * Send alert notification
   */
  async sendAlertNotification(alert) {
    try {
      const subject = `Backup Alert - ${alert.type}`;
      const message = this.generateAlertMessage(alert);
      
      await notificationService.sendSystemNotification({
        type: 'backup_alert',
        title: subject,
        message,
        severity: alert.severity,
        data: alert
      });

    } catch (error) {
      loggingService.logError('Failed to send alert notification', error);
    }
  }

  /**
   * Generate alert message
   */
  generateAlertMessage(alert) {
    let message = `${alert.message}\n\n`;
    message += `Alert ID: ${alert.id}\n`;
    message += `Type: ${alert.type}\n`;
    message += `Severity: ${alert.severity}\n`;
    message += `Timestamp: ${alert.timestamp}\n\n`;
    
    if (alert.data) {
      message += 'Details:\n';
      Object.entries(alert.data).forEach(([key, value]) => {
        message += `- ${key}: ${value}\n`;
      });
    }
    
    return message;
  }

  /**
   * Generate Prometheus metrics
   */
  generatePrometheusMetrics() {
    const metrics = [];
    
    // Backup job metrics
    metrics.push(`# HELP backup_jobs_total Total number of backup jobs`);
    metrics.push(`# TYPE backup_jobs_total counter`);
    metrics.push(`backup_jobs_total ${this.metrics.backupJobs.total}`);
    
    metrics.push(`# HELP backup_jobs_successful_total Total number of successful backup jobs`);
    metrics.push(`# TYPE backup_jobs_successful_total counter`);
    metrics.push(`backup_jobs_successful_total ${this.metrics.backupJobs.successful}`);
    
    metrics.push(`# HELP backup_jobs_failed_total Total number of failed backup jobs`);
    metrics.push(`# TYPE backup_jobs_failed_total counter`);
    metrics.push(`backup_jobs_failed_total ${this.metrics.backupJobs.failed}`);
    
    // Restore test metrics
    metrics.push(`# HELP restore_tests_total Total number of restore tests`);
    metrics.push(`# TYPE restore_tests_total counter`);
    metrics.push(`restore_tests_total ${this.metrics.restoreTests.total}`);
    
    metrics.push(`# HELP restore_tests_successful_total Total number of successful restore tests`);
    metrics.push(`# TYPE restore_tests_successful_total counter`);
    metrics.push(`restore_tests_successful_total ${this.metrics.restoreTests.successful}`);
    
    metrics.push(`# HELP restore_tests_failed_total Total number of failed restore tests`);
    metrics.push(`# TYPE restore_tests_failed_total counter`);
    metrics.push(`restore_tests_failed_total ${this.metrics.restoreTests.failed}`);
    
    // Storage metrics
    metrics.push(`# HELP backup_storage_total_bytes Total storage size in bytes`);
    metrics.push(`# TYPE backup_storage_total_bytes gauge`);
    metrics.push(`backup_storage_total_bytes ${this.metrics.storage.totalSize}`);
    
    metrics.push(`# HELP backup_storage_used_bytes Used storage size in bytes`);
    metrics.push(`# TYPE backup_storage_used_bytes gauge`);
    metrics.push(`backup_storage_used_bytes ${this.metrics.storage.usedSize}`);
    
    metrics.push(`# HELP backup_storage_available_bytes Available storage size in bytes`);
    metrics.push(`# TYPE backup_storage_available_bytes gauge`);
    metrics.push(`backup_storage_available_bytes ${this.metrics.storage.availableSize}`);
    
    // Performance metrics
    metrics.push(`# HELP backup_average_duration_seconds Average backup duration in seconds`);
    metrics.push(`# TYPE backup_average_duration_seconds gauge`);
    metrics.push(`backup_average_duration_seconds ${this.metrics.performance.averageBackupDuration / 1000}`);
    
    metrics.push(`# HELP restore_average_duration_seconds Average restore duration in seconds`);
    metrics.push(`# TYPE restore_average_duration_seconds gauge`);
    metrics.push(`restore_average_duration_seconds ${this.metrics.performance.averageRestoreDuration / 1000}`);
    
    // Alert metrics
    metrics.push(`# HELP backup_alerts_active Active backup alerts`);
    metrics.push(`# TYPE backup_alerts_active gauge`);
    metrics.push(`backup_alerts_active ${this.metrics.alerts.active}`);
    
    metrics.push(`# HELP backup_alerts_critical Critical backup alerts`);
    metrics.push(`# TYPE backup_alerts_critical gauge`);
    metrics.push(`backup_alerts_critical ${this.metrics.alerts.critical}`);
    
    metrics.push(`# HELP backup_alerts_warning Warning backup alerts`);
    metrics.push(`# TYPE backup_alerts_warning gauge`);
    metrics.push(`backup_alerts_warning ${this.metrics.alerts.warning}`);
    
    return metrics.join('\n');
  }

  /**
   * Generate Grafana dashboard data
   */
  generateGrafanaDashboardData() {
    return {
      dashboard: {
        title: 'Secure Gate Backup Monitoring',
        panels: [
          {
            title: 'Backup Jobs Status',
            type: 'stat',
            targets: [
              {
                expr: 'backup_jobs_total',
                legendFormat: 'Total Jobs'
              },
              {
                expr: 'backup_jobs_successful_total',
                legendFormat: 'Successful'
              },
              {
                expr: 'backup_jobs_failed_total',
                legendFormat: 'Failed'
              }
            ]
          },
          {
            title: 'Storage Usage',
            type: 'gauge',
            targets: [
              {
                expr: 'backup_storage_used_bytes / backup_storage_total_bytes * 100',
                legendFormat: 'Usage %'
              }
            ]
          },
          {
            title: 'Backup Duration Trend',
            type: 'graph',
            targets: [
              {
                expr: 'backup_average_duration_seconds',
                legendFormat: 'Average Duration'
              }
            ]
          },
          {
            title: 'Active Alerts',
            type: 'stat',
            targets: [
              {
                expr: 'backup_alerts_active',
                legendFormat: 'Active Alerts'
              },
              {
                expr: 'backup_alerts_critical',
                legendFormat: 'Critical'
              },
              {
                expr: 'backup_alerts_warning',
                legendFormat: 'Warning'
              }
            ]
          }
        ]
      }
    };
  }

  /**
   * Generate Alertmanager configuration
   */
  generateAlertmanagerConfig() {
    return {
      global: {
        smtp_smarthost: process.env.SMTP_HOST || 'localhost:587',
        smtp_from: process.env.SMTP_FROM || 'alerts@securegate.local'
      },
      route: {
        group_by: ['alertname'],
        group_wait: '10s',
        group_interval: '10s',
        repeat_interval: '1h',
        receiver: 'web.hook'
      },
      receivers: [
        {
          name: 'web.hook',
          webhook_configs: [
            {
              url: process.env.ALERT_WEBHOOK_URL || 'http://localhost:5001/alerts'
            }
          ]
        }
      ],
      rules: [
        {
          alert: 'BackupJobFailed',
          expr: 'backup_jobs_failed_total > 0',
          for: '5m',
          labels: {
            severity: 'critical'
          },
          annotations: {
            summary: 'Backup job failed',
            description: 'A backup job has failed'
          }
        },
        {
          alert: 'RestoreTestFailed',
          expr: 'restore_tests_failed_total > 0',
          for: '5m',
          labels: {
            severity: 'critical'
          },
          annotations: {
            summary: 'Restore test failed',
            description: 'A restore test has failed'
          }
        },
        {
          alert: 'StorageUsageHigh',
          expr: 'backup_storage_used_bytes / backup_storage_total_bytes * 100 > 90',
          for: '5m',
          labels: {
            severity: 'warning'
          },
          annotations: {
            summary: 'Storage usage is high',
            description: 'Backup storage usage is above 90%'
          }
        }
      ]
    };
  }

  /**
   * Generate alert ID
   */
  generateAlertId() {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substr(2, 9);
    return `alert-${timestamp}-${random}`;
  }

  /**
   * Get monitoring status
   */
  getMonitoringStatus() {
    return {
      metrics: this.metrics,
      alertRules: this.alertRules,
      prometheusMetrics: this.generatePrometheusMetrics(),
      grafanaDashboard: this.generateGrafanaDashboardData(),
      alertmanagerConfig: this.generateAlertmanagerConfig()
    };
  }

  /**
   * Get service status
   */
  getStatus() {
    return {
      initialized: true,
      metrics: this.metrics,
      alertRules: Object.keys(this.alertRules),
      activeAlerts: this.metrics.alerts.active
    };
  }
}

// Create singleton instance
const backupMonitoringService = new BackupMonitoringService();

export default backupMonitoringService;
